# Cinema Cut Pro — icon pack

Full-bleed master art: the cut-film-reel on the graphite squircle plate.
The art matches the reference board 1:1 (measured geometry: reel ⌀ 62.8 % of tile, six ⌀ 6.5 % holes on a
4.66-reel-radius ring every 60°, hub ⌀ 6.8 %, the −20.5° slice through the centre carrying the top-half shear).

## Palette (from the measured reference)

| token | value |
|---|---|
| plate top-left | `#464648` |
| plate bottom-right | `#09090B` |
| plate centre | `#151517` |
| reel top-left | `#F04259` |
| reel bottom-right | `#9E000C` |
| ink / wordmark | `#E4324A` |

## Folders

- `design/` — SVG masters (1024), squircle preview, and the three Android adaptive layers (vector sources).
- `ios/` — `AppIcon.appiconset/` with every size + Contents.json. Drop into Xcode (Assets.xcassets).
  All PNGs are 100 % opaque squares — required for App Store validation (no alpha, no pre-rounded corners).
- `android/` — `res/` tree: adaptive-icon XML (bg + fg + monochrome), 5-density PNG layers (108dp),
  legacy `ic_launcher(.round)` mipmaps 48–192. Copy `res/` into your app module; reference
  `@mipmap/ic_launcher` in the manifest.
- `stores/` — 1024 (App Store), 512 (Play), 1200 OG card. Flat colour, no shadow/alpha.
- `web/` — favicons (16–64), `.ico`, apple-touch 180 (squircle), PWA manifest 192/512 (+maskable), snippets.html.
- `app/` — in-app UI kit: rounded tiles 24–256, bare reel marks, `currentColor` micro glyphs 16–32,
  light/dark ink reels for toolbars.

## Notes

- Foreground layer keeps the cuts as re-painted plate colour; the launcher's background layer carries the
  same plate gradient, so the composite is pixel-identical to the master while still de-clipping correctly
  on every mask (circle / squircle / rounded).
- Android 13 themed icons: `ic_launcher_monochrome` is the reel silhouette + slice, single colour.
- V2 variant: small red **pro** wordmark sits under a lifted reel; sized to stay inside the 66 dp safe zone.
